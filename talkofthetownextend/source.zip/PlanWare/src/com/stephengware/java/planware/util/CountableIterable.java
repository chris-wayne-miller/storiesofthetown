package com.stephengware.java.planware.util;

public interface CountableIterable<T> extends Iterable<T> {

	public int size();
}
