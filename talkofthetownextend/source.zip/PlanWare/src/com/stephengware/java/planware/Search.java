package com.stephengware.java.planware;

public abstract class Search {
	
	public abstract Result getNextPlan(ArgumentMap arguments);
}
