package com.stephengware.java.planware.io;

public class BuildException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public BuildException(String message){
		super(message);
	}
}
